<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FeedbackType extends Model
{
    protected $fillable = ['name', 'email'];

    public function categories()
    {
        return $this->hasMany(FeedbackCategory::class, 'type_id');
    }
}
