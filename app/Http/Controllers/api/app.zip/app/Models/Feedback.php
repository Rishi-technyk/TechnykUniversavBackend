<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Feedback extends Model
{
     protected $table = 'feedbacks';
    protected $fillable = ['member_id','type_id','category_id','description'];

    public function type() {
        return $this->belongsTo(FeedbackType::class);
    }

    public function category() {
        return $this->belongsTo(FeedbackCategory::class);
    }

    public function user() {
        return $this->belongsTo(User::class, 'member_id');
    }

    public function member() {
        return $this->belongsTo(Member::class, 'member_id');
    }
}
