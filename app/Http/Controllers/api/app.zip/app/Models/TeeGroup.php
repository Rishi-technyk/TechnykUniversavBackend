<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeeGroup extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'tee_my_groups';
    
     public function player1()
    {
        return $this->belongsTo(Member::class, 'player1_id', 'id')
                    ->select('id','MemberID', 'DisplayName');
    }

    public function player2()
    {
        return $this->belongsTo(Member::class, 'player2_id', 'id')
                    ->select('id','MemberID', 'DisplayName');
    }

    public function player3()
    {
        return $this->belongsTo(Member::class, 'player3_id', 'id')
                    ->select('id','MemberID', 'DisplayName');
    }

    public function player4()
    {
        return $this->belongsTo(Member::class, 'player4_id', 'id')
                    ->select('id','MemberID', 'DisplayName');
    }

    protected $fillable = ['player1_id','player2_id','player3_id','player4_id','group_name','tee_session_id', 'is_active', 'created_by', 'updated_by'];
    
    public function session()
{
    return $this->belongsTo(TeeSession::class, 'tee_session_id');
}

}

?>