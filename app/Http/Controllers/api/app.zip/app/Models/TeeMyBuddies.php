<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TeeMyBuddies extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'tee_my_buddies';

    protected $fillable = ['member_id', 'is_active', 'created_by','tee_session_id', 'updated_by'];
    
     public function member()
    {
        return $this->belongsTo(Member::class, 'member_id', 'id')
          ->select('id','MemberID', 'DisplayName','CategoryCode','Email');
    }
    

    /**
     * Get the user who created this buddy.
     */
    public function creator()
    {
        return $this->belongsTo(Member::class, 'created_by', 'id');
    }
}

?>