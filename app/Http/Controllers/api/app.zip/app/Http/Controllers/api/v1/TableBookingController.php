<?php
namespace App\Http\Controllers\api\v1;
use App\Http\Controllers\Controller;

use App\Models\TableBooking;
use App\Models\Table;
use App\Models\TableMeal;
use App\Models\TableTime;
use App\Models\TableVenue;
use Illuminate\Http\Request;

class TableBookingController extends Controller
{
    
//     public function availability(Request $request)
// {
//     $member_id = auth()->id();

//     $days = 3;
//     $dates = collect(range(0, $days - 1))
//         ->map(fn ($i) => now()->addDays($i)->toDateString());

//     $response = [];

//     foreach ($dates as $date) {

//         $times = TableTime::where('status','Active')->get();

//         $timeData = [];

//         foreach ($times as $time) {

//             $venues = TableVenue::where('status','Active')->get();

//             $venueData = [];

//             foreach ($venues as $venue) {

//                 $bookedTableIds = TableBooking::where([
//                         'booking_date' => $date,
//                         'time_id' => $time->id,
//                         'venue_id' => $venue->id,
//                         'status' => 'Booked'
//                     ])->pluck('table_id');

//                 $tables = Table::where('status','Active')
//                     ->whereNotIn('id', $bookedTableIds)
//                     ->get(['id','name']);

//                 if ($tables->count() > 0) {
//                     $venueData[] = [
//                         'id' => $venue->id,
//                         'name' => $venue->name,
//                         'tables' => $tables
//                     ];
//                 }
//             }

//             if (!empty($venueData)) {
//                 $timeData[] = [
//                     'id' => $time->id,
//                     'time' => $time->time,
//                     'venues' => $venueData
//                 ];
//             }
//         }

//         $response[] = [
//             'date' => $date,
//             'times' => $timeData,
//             'day_open_booking'=>$days,
//         ];
//     }

//     return response()->json([
//         'status' => true,
//         'data' => $response
//     ]);
// }
public function availability(Request $request)
{
    $days = 3;

    $dates = collect(range(0, $days - 1))
        ->map(fn ($i) => now()->addDays($i)->toDateString());

    $meals = TableMeal::where('status','Active')->get();

    $response = [];

    foreach ($dates as $date) {

        $mealData = [];

        foreach ($meals as $meal) {

            $times = TableTime::where([
                'status' => 'Active',
                'meal_id' => $meal->id
            ])->get();

            $timeData = [];

            foreach ($times as $time) {

                $venues = TableVenue::where('status','Active')->get();

                $venueData = [];

                foreach ($venues as $venue) {

                    $bookedTableIds = TableBooking::where([
                        'booking_date' => $date,
                        'meal_id' => $meal->id,
                        'time_id' => $time->id,
                        'venue_id' => $venue->id,
                        'status' => 'Booked'
                    ])->pluck('table_id');

                    $tables = Table::where([
                            'status' => 'Active',
                            'meal_id' => $meal->id
                        ])
                        ->whereNotIn('id', $bookedTableIds)
                        ->get(['id','name']);

                    if ($tables->count() > 0) {
                        $venueData[] = [
                            'id' => $venue->id,
                            'name' => $venue->name,
                            'tables' => $tables
                        ];
                    }
                }

                if (!empty($venueData)) {
                    $timeData[] = [
                        'id' => $time->id,
                        'time' => $time->time,
                        'venues' => $venueData
                    ];
                }
            }

            if (!empty($timeData)) {
                $mealData[] = [
                    'id' => $meal->id,
                    'name' => $meal->name,
                    'times' => $timeData
                ];
            }
        }

        $response[] = [
            'date' => $date,
            'meals' => $mealData,
        ];
    }

    return response()->json([
        'status' => true,
        'data' => $response,
        'day_open_booking' => $days
    ]);
}


  public function getMeals()
{
    $meals = TableMeal::where('status','Active')->get();

    return response()->json([
        'status' => true,
        'data' => $meals
    ]);
}
public function getTimes($meal_id)
{
    $times = TableTime::where('meal_id',$meal_id)
                ->where('status','Active')
                ->get();

    return response()->json([
        'status' => true,
        'data' => $times
    ]);
}
public function getVenues()
{
    $venues = TableVenue::where('status','Active')->get();

    return response()->json([
        'status' => true,
        'data' => $venues
    ]);
}
public function getTables($meal_id)
{
    $tables = Table::where('meal_id',$meal_id)
                ->where('status','Active')
                ->get();

    return response()->json([
        'status' => true,
        'data' => $tables
    ]);
}
public function checkAvailability(Request $request)
{
    $request->validate([
        'meal_id' => 'required',
        'venue_id' => 'required',
        'time_id' => 'required',
        'booking_date' => 'required|date'
    ]);

    $bookedTables = TableBooking::where([
            'meal_id' => $request->meal_id,
            'venue_id' => $request->venue_id,
            'time_id' => $request->time_id,
            'booking_date' => $request->booking_date,
            'status' => 'Booked'
        ])->pluck('table_id');

    $availableTables = Table::where('meal_id',$request->meal_id)
        ->whereNotIn('id',$bookedTables)
        ->where('status','Active')
        ->get();

    return response()->json([
        'status' => true,
        'available_tables' => $availableTables
    ]);
}
public function createBooking(Request $request)
{
    $request->validate([
        'meal_id' => 'required',
        'venue_id' => 'required',
        'time_id' => 'required',
        'table_id' => 'required',
        'booking_date' => 'required|date'
    ]);

    // Prevent double booking
    $exists = TableBooking::where([
        'table_id' => $request->table_id,
        'booking_date' => $request->booking_date,
        'time_id' => $request->time_id,
        'status' => 'Booked'
    ])->exists();

    if ($exists) {
        return response()->json([
            'status' => false,
            'message' => 'Table already booked'
        ]);
    }
$member_id= auth()->user()->id;
    $booking = TableBooking::create([
        'member_id' => $member_id,
        'meal_id' => $request->meal_id,
        'venue_id' => $request->venue_id,
        'time_id' => $request->time_id,
        'table_id' => $request->table_id,
        'booking_date' => $request->booking_date,
        'status' => 'Booked'
    ]);

    return response()->json([
        'status' => true,
        'message' => 'Booking Successful',
        'data' => $booking
    ]);
}
public function updateBooking(Request $request, $id)
{
    $booking = TableBooking::findOrFail($id);

    if ($booking->status == 'Cancelled') {
        return response()->json([
            'status' => false,
            'message' => 'Cannot edit cancelled booking'
        ]);
    }

    $booking->update($request->all());

    return response()->json([
        'status' => true,
        'message' => 'Booking Updated',
        'data' => $booking
    ]);
}
public function cancelBooking($id)
{
    $booking = TableBooking::findOrFail($id);

    $booking->update([
        'status' => 'Cancelled'
    ]);

    return response()->json([
        'status' => true,
        'message' => 'Booking Cancelled'
    ]);
}
public function myBookings(Request $request)
{
    $member_id = auth()->user()->id;

    $status = $request->status; // Booked / Cancelled
    $type   = $request->type;   // upcoming / past

    $query = TableBooking::with([
            'table:id,name',
            'meal:id,name',
            'time:id,time',
            'venue:id,name'
        ])
        ->where('member_id', $member_id);

    // Filter by status
    if ($status) {
        $query->where('status', $status);
    }

    // Filter upcoming or past
    if ($type === 'upcoming') {
        $query->whereDate('booking_date', '>=', now()->toDateString());
    }

    if ($type === 'past') {
        $query->whereDate('booking_date', '<', now()->toDateString());
    }

    $bookings = $query->latest()
        ->paginate(10);

    return response()->json([
        'status' => true,
        'message' => 'Bookings fetched successfully',
        'data' => $bookings
    ]);
}
public function getBookingByID($id)
{
    $member_id = auth()->id();

    $booking = TableBooking::with([
            'meal:id,name',
            'time:id,time',
            'venue:id,name',
            'table:id,name'
        ])
        ->where('id', $id)
        ->where('member_id', $member_id)
        ->first();

    if (!$booking) {
        return response()->json([
            'status' => false,
            'message' => 'Booking not found'
        ], 404);
    }

    return response()->json([
        'status' => true,
        'message' => 'Booking fetched successfully',
        'data' => $booking
    ]);
}


}
